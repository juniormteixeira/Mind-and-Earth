# Mind & Earth Website

**Mind & Earth** is a website dedicated to promoting mental health awareness and sustainable living practices. It provides resources for individuals to improve their mental well-being and live more eco-friendly lifestyles.

## Features
- **Mental Health Support:** Articles, personal stories, and professional guidance.
- **Sustainable Practices:** Green living tips and DIY eco-friendly projects.
- **Community Forum:** A space for discussions and sharing experiences.
- **Resource Center:** Curated links to mental health services and sustainability guides.

## Created By
Junior Teixeira & Everton Teixeira
